//TO DO 
#include <util/delay.h>
#include "mcc_generated_files/system/system.h"
#include <util/delay.h>
#define TRUNCATED_SHIFT 4
#define NUM_PINS 4


//#define TRUNCATED_SHIFT 4  /* Total number of SAMPLES accumulated are 128. Since this is truncated down to 16 bits, dividing ADC result by 16 or right shifting by 4 will give the average 12-bit ADC result */ 
#define MAX_VOLTAGE	 3.3
#define ADC_RESOLUTION 0x0FFF /* In the test setup, VDD = 3.3V, ADC ref is VDD. 12 bit ADC count is 4095 at 3.3V */

struct
{
    uint32_t result;
    uint16_t average_result;
} adc_data[NUM_PINS];
float voltage;


void setLow(int n) {
    switch (n) {
        case 0: CTR_0_SetLow(); break;
        case 1: CTR_1_SetLow(); break;
        case 2: CTR_2_SetLow(); break;
        case 3: CTR_3_SetLow(); break;
//        case 4: CTR_4_SetLow(); break;
//        case 5: CTR_5_SetLow(); break;
//        case 6: CTR_6_SetLow(); break;
//        case 7: CTR_7_SetLow(); break;
//        case 8: CTR_8_SetLow(); break;
//        case 9: CTR_9_SetLow(); break;
        default: printf("Invalid input: %d\n", n); break;
    }
}
void setHigh(int n) {
    switch (n) {
        case 0: CTR_0_SetHigh(); break;
        case 1: CTR_1_SetHigh(); break;
        case 2: CTR_2_SetHigh(); break;
        case 3: CTR_3_SetHigh(); break;
//        case 4: CTR_4_SetHigh(); break;
//        case 5: CTR_5_SetHigh(); break;
//        case 6: CTR_6_SetHigh(); break;
//        case 7: CTR_7_SetHigh(); break;
//        case 8: CTR_8_SetHigh(); break;
//        case 9: CTR_9_SetHigh(); break;
        default: printf("Invalid input: %d\n", n); break;
    }
}
void setInput(int n) {
    switch (n) {
        case 0: CTR_0_SetDigitalInput(); break;
        case 1: CTR_1_SetDigitalInput(); break;
        case 2: CTR_2_SetDigitalInput(); break;
        case 3: CTR_3_SetDigitalInput(); break;
//        case 4: CTR_4_SetHigh(); break;
//        case 5: CTR_5_SetHigh(); break;
//        case 6: CTR_6_SetHigh(); break;
//        case 7: CTR_7_SetHigh(); break;
//        case 8: CTR_8_SetHigh(); break;
//        case 9: CTR_9_SetHigh(); break;
        default: printf("Invalid input: %d\n", n); break;
    }
}
void setOutput(int n) {
    switch (n) {
        case 0: CTR_0_SetDigitalOutput(); break;
        case 1: CTR_1_SetDigitalOutput(); break;
        case 2: CTR_2_SetDigitalOutput(); break;
        case 3: CTR_3_SetDigitalOutput(); break;
//        case 4: CTR_4_SetHigh(); break;
//        case 5: CTR_5_SetHigh(); break;
//        case 6: CTR_6_SetHigh(); break;
//        case 7: CTR_7_SetHigh(); break;
//        case 8: CTR_8_SetHigh(); break;
//        case 9: CTR_9_SetHigh(); break;
        default: printf("Invalid input: %d\n", n); break;
    }
}

float process_adc_conversion(uint8_t current_channel) {
    // Wait for the previous ADC conversion to complete
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    
    // Clear the result ready flag
    ADC0.INTFLAGS = ADC_RESRDY_bm;
    
    // Start ADC conversion
    ADC0_StartConversion(current_channel);
    
    // Wait for the conversion to complete
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    
    // Get the conversion result and store it temporarily
    uint16_t result = ADC0_GetConversionResult();
    uint16_t average_result = (uint16_t)(result >> TRUNCATED_SHIFT);
    
    // Calculate the voltage
    float voltage = (float)(average_result * MAX_VOLTAGE) / ADC_RESOLUTION;
    
    // Clear all stored ADC-related data for this channel
    adc_data[current_channel].result = 0;
    adc_data[current_channel].average_result = 0;
    
    return voltage;
}


int main(void)
{   
    ADC0_SetWindowChannel(0);
    SYSTEM_Initialize();
    ADC0_EnableAutoTrigger();
    int open_test = 0;
    int short_test = 0;
    int diode_test = 0;
    int resistor_test = 0;
    float vcc_A = 3.30;
    float vcc_B = 3.30;
    float test_a;
    float test_b;
    int i;
    CTR_0_SetDigitalInput();
    CTR_1_SetDigitalInput();
    CTR_2_SetDigitalInput();
    CTR_3_SetDigitalInput();
    
    while(1)
    {       

//        setLow(0);
//        process_adc_conversion(0);
//        test_a = process_adc_conversion(0);
//        setHigh(1);
//        process_adc_conversion(1);
//        test_b = process_adc_conversion(1);
//        printf("Pin %d Voltage:  %.3f\n", 0, test_a);
//        printf("Pin %d Voltage:  %.3f\n", 1, test_b);
        
        for (i = 0; i < NUM_PINS - 1; i++) {
            for (int j = 0; j < NUM_PINS - 1; j++) {                  
                open_test = 0;
                short_test = 0;
                diode_test = 0;
                resistor_test = 0;
                setLow(i);
                setLow(j);
                if (i != j) {
                    setOutput(i);
                    setOutput(j);
                    printf("Check for pair %d, %d\n", i, j);
                    printf("Pin A Vcc:%.2f    Pin B Vcc:%.2f\n", vcc_A, vcc_B);
                    // Both Low Test
                    test_a = process_adc_conversion(i);
                    test_b = process_adc_conversion(j);
                    printf("Both Low Test\nPin %d Voltage:  %.3f\nPin %d Voltage:  %.3f\n", i, test_a, j, test_b);
                    if (test_a < 0.10 && test_b < 0.10) {
                        open_test++;
                        short_test++;
                        diode_test++;
                        resistor_test++;
                    }

                    // Test 1: i High, j Low
                    setHigh(i);
                    setLow(j);
                    test_a = process_adc_conversion(i);
                    test_b = process_adc_conversion(j);
                    printf("A High, B Low\nPin %d Voltage:  %.3f\nPin %d Voltage:  %.3f\n", i, test_a, j, test_b);
                    if (test_a > (vcc_A - 0.1) && test_b < 0.10) {
                        open_test++;
                    } else if ((test_b > ((vcc_B / 2) - 0.1) && test_a < ((vcc_B / 2) + 0.1)) && (test_a > ((vcc_A / 2) - 0.1) && test_a < ((vcc_A / 2) + 0.1))) {
                        // short test 
                        short_test++;
                    } else if (test_a < 0.10 && test_b < 0.10) {
                        // diode test 
                        diode_test++;
                    }

                    // Test 2: i Low, j High
                    setLow(i);
                    setHigh(j);
                    test_a = process_adc_conversion(i);
                    test_b = process_adc_conversion(j);
                    printf("A Low, B High\nPin %d Voltage:  %.3f\nPin %d Voltage:  %.3f\n", i, test_a, j, test_b);
                    if (test_b > (vcc_B - 0.1) && test_a < 0.10) {
                        open_test++;
                    } else if ((test_b > ((vcc_B / 2) - 0.1) && test_b < ((vcc_B / 2) + 0.1)) && (test_a > ((vcc_A / 2) - 0.1) && test_a < ((vcc_A / 2) + 0.1))) {
                        // short test 
                        short_test++;
                    } else if (test_a > (vcc_A - 0.1) && test_b > (vcc_B - 0.1)) {
                        // diode test
                        diode_test++;
                    }

                    // Test 3: Both High
                    setHigh(i);
                    setHigh(j);
                    test_a = process_adc_conversion(i);
                    test_b = process_adc_conversion(j);
                    printf("Both High\nPin %d Voltage:  %.3f\nPin %d Voltage:  %.3f\n", i, test_a, j, test_b);
                    if (test_a > (vcc_A - 0.1) && test_b > (vcc_B - 0.1)) {
                        open_test++;
                        short_test++;
                        diode_test++;
                        resistor_test++;
                    }
                    setLow(i);
                    setLow(j);
                    printf("Connection Type for pair %d %d:\nOpen:%d\nShort:%d\nDiode:%d\nResistor:%d\n\n", i, j, open_test, short_test, diode_test, resistor_test);
                    setInput(i);
                    setInput(j);
                }
            }
        }

        printf("Full Test Complete!!!!!!!!!!!\n\n");
        
}    
}